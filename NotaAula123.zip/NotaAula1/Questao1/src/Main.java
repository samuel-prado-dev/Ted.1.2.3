import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar nome e notas do aluno
        System.out.println("Digite o nome do aluno:");
        String nome = scanner.nextLine();

        System.out.println("Digite as 3 notas do aluno:");
        double nota1 = scanner.nextDouble();
        double nota2 = scanner.nextDouble();
        double nota3 = scanner.nextDouble();

        // Calcular média
        double media = (nota1 + nota2 + nota3) / 3;

        // Determinar situação
        if (media >= 70) {
            System.out.println("Aluno " + nome + " está APROVADO com média " + media);
        } else if (media < 40) {
            System.out.println("Aluno " + nome + " está REPROVADO com média " + media);
        } else {
            System.out.println("Aluno " + nome + " está de RECUPERAÇÃO com média " + media);
        }

        scanner.close();
    }
}
