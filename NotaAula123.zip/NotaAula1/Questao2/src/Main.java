import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Implementar cadastro de produto, venda e controle de estoque
        System.out.println("Bem-vindo ao sistema de controle de produtos!");
        // Resto do código aqui...
    }
}
