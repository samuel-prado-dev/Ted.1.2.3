public class TesteCorridaUber {
    public static void main(String[] args) {
        CorridaUber corrida = new CorridaUber(10, 5, 15.0, 1.2);

        corrida.exibirDetalhesCorrida();
    }
}
