public class ContaCorrente extends Conta {
    private static final double CHEQUE_ESPECIAL_LIMITE = 1000.0;
    private double chequeEspecial;

    public ContaCorrente(double saldoInicial) {
        super(saldoInicial);
        this.chequeEspecial = CHEQUE_ESPECIAL_LIMITE;
    }

    @Override
    public void sacar(double valor) {
        if (valor <= saldo + chequeEspecial) {
            saldo -= valor;
            if (saldo < 0) {
                chequeEspecial += saldo;
                saldo = 0;
            }
        } else {
            System.out.println("Saldo e cheque especial insuficientes.");
        }
    }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Cheque especial disponível: " + chequeEspecial);
    }
}
