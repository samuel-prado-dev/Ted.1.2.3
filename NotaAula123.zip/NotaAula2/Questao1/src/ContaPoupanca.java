public class ContaPoupanca extends Conta {
    private double selic;

    public ContaPoupanca(double saldoInicial, double selic) {
        super(saldoInicial);
        this.selic = selic;
    }

    public void calcularRendimento() {
        double rendimento;
        if (selic > 8.5) {
            rendimento = 0.005 * saldo;
        } else {
            rendimento = 0.007 * selic * saldo;
        }
        saldo += rendimento;
    }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Taxa Selic: " + selic + "%");
    }
}
