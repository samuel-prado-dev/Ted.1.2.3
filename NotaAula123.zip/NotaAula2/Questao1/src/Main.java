public class Banco {
    public static void main(String[] args) {
        ContaCorrente contaCorrente = new ContaCorrente(500);
        ContaPoupanca contaPoupanca = new ContaPoupanca(1000, 7.0);

        System.out.println("Conta Corrente:");
        contaCorrente.depositar(200);
        contaCorrente.sacar(700);
        contaCorrente.exibirDados();

        System.out.println("\nConta Poupança:");
        contaPoupanca.depositar(300);
        contaPoupanca.calcularRendimento();
        contaPoupanca.sacar(200);
        contaPoupanca.exibirDados();
    }
}
